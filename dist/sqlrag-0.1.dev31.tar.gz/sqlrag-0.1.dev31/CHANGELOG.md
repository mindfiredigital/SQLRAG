# CHANGELOG

## v0.1.0 (2024-10-01)

### Feature

* feat: initial release ([`60dd5df`](https://github.com/mindfiredigital/SQLRAG/commit/60dd5df45380a6355021be043772dd1b9e5defe0))

### Fix

* fix: delete toml file ([`8ca24ed`](https://github.com/mindfiredigital/SQLRAG/commit/8ca24edf240f474eaeb02ba1bedb9000c9b82f43))

* fix: modified workflow.yml ([`418e40a`](https://github.com/mindfiredigital/SQLRAG/commit/418e40a2404e02c61786fb9f5797fd0a67b084db))

* fix: add workflow dispatch ([`0a27a40`](https://github.com/mindfiredigital/SQLRAG/commit/0a27a4033ce26b3d05fe72be24884d74e22f2f3a))

* fix: merge branch ([`7e97de4`](https://github.com/mindfiredigital/SQLRAG/commit/7e97de4dc5d9b6e03cd42b9235fc038ba3d1fe35))

### Unknown

* Merge pull request #3 from mindfiredigital/dev

fix: delete toml file ([`d45cb27`](https://github.com/mindfiredigital/SQLRAG/commit/d45cb276fb39a1e30fcf208c2c8ed17c9739146d))

* Merge pull request #2 from mindfiredigital/dev

fix: modified workflow.yml ([`ad55c34`](https://github.com/mindfiredigital/SQLRAG/commit/ad55c34f361b1fca8b935e29837adb225907a3fd))

* Merge pull request #1 from mindfiredigital/dev

fix: add workflow dispatch ([`459d6e3`](https://github.com/mindfiredigital/SQLRAG/commit/459d6e320766e3935dbb1d59630a30086775fd14))

* Initial commit ([`bf2e991`](https://github.com/mindfiredigital/SQLRAG/commit/bf2e99156f2c34b167a2ffc31e359b3673c926a0))
